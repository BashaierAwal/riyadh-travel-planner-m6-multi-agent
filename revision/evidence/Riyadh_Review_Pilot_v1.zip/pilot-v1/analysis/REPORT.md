# Revised experiment results

Status: **complete**. Records: 2/2. Evidence: live.

## Combined cases

| Metric | Condition | Mean | SD of seed means | Pass on all three runs |
|---|---|---:|---:|---:|
| APM | baseline | 100.000 | 0.000 | — |
| APM | treatment | 100.000 | 0.000 | — |
| RBM | baseline | 100.000 | 0.000 | — |
| RBM | treatment | 100.000 | 0.000 | — |
| HBM | baseline | 100.000 | 0.000 | — |
| HBM | treatment | 100.000 | 0.000 | — |
| IFR | baseline | 100.000 | 0.000 | — |
| IFR | treatment | 100.000 | 0.000 | — |
| RTC | baseline | 100.000 | 0.000 | — |
| RTC | treatment | 100.000 | 0.000 | — |
| constraint_pass | baseline | 100.000 | 0.000 | — |
| constraint_pass | treatment | 100.000 | 0.000 | — |
| violation_count | baseline | 0.000 | 0.000 | — |
| violation_count | treatment | 0.000 | 0.000 | — |
| repair_rounds | baseline | 0.000 | 0.000 | — |
| repair_rounds | treatment | 0.000 | 0.000 | — |
| tool_calls | baseline | 5.000 | 0.000 | — |
| tool_calls | treatment | 6.000 | 0.000 | — |
| system_wall_seconds | baseline | 72.893 | 0.000 | — |
| system_wall_seconds | treatment | 95.806 | 0.000 | — |

Paired differences use one average per case, keeping its three seeds together. The JSON report includes 95% bootstrap intervals and paired sign-flip tests. Secondary comparisons are exploratory; a small numerical lead is not automatically evidence of improvement.

## Failure analysis

Labels: no output; unknown dataset place; repeated activity; budget; distance; interest quota; structure; missing information; selection not found in searched candidates. All failed records remain in the denominator. A missing plan receives a recorded no-output violation; it is not treated as a plan with zero travel violations.

See SUMMARY.json for counts and real examples. Component-removal results are needed before linking a common failure to a particular design choice.
