# Revised experiment results

Status: **incomplete**. Records: 34/240. Evidence: live.

## Failure analysis

Labels: no output; unknown dataset place; repeated activity; budget; distance; interest quota; structure; missing information; selection not found in searched candidates. All failed records remain in the denominator. A missing plan receives a recorded no-output violation; it is not treated as a plan with zero travel violations.

See SUMMARY.json for counts and real examples. Component-removal results are needed before linking a common failure to a particular design choice.
